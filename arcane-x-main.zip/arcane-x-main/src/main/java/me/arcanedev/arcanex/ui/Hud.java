package me.arcanedev.arcanex.ui;

import me.arcanedev.arcanex.ArcaneX;
import me.arcanedev.arcanex.module.Category;
import me.arcanedev.arcanex.module.Module;
import me.arcanedev.arcanex.module.ModuleManager;
import me.arcanedev.arcanex.ui.tab.SubTab;
import me.arcanedev.arcanex.ui.tab.Tab;
import me.arcanedev.arcanex.ui.tab.TabGui;
import me.arcanedev.arcanex.util.Refrence;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import org.lwjgl.input.Keyboard;

import java.awt.*;
import java.util.List;
import java.util.*;

import static net.minecraft.client.Minecraft.getMinecraft;

public class Hud extends Gui {
	public enum BracketColor {
        DarkRed, Red, Gold, Yellow, DarkGreen, Green, Aqua, DarkAqua, DarkBlue, Blue, LightPurple, DarkPurple, White, Gray, DarkGray, Black
    }

    public enum NameColor {
        DarkRed, Red, Gold, Yellow, DarkGreen, Green, Aqua, DarkAqua, DarkBlue, Blue, LightPurple, DarkPurple, White, Gray, DarkGray, Black

    }

    public void initTabGui() {
        HashMap<Category, List<Module>> moduleCategoryMap = new HashMap<>();

        for (Module module : ModuleManager.getModuleList()) {
            if (!moduleCategoryMap.containsKey(module.getCategory())) {
                moduleCategoryMap.put(module.getCategory(), new ArrayList<>());
            }

            moduleCategoryMap.get(module.getCategory()).add(module);
        }

        for (Map.Entry<Category, List<Module>> moduleCategoryListEntry : moduleCategoryMap.entrySet()) {
            Tab<Module> tab = new Tab<>(moduleCategoryListEntry.getKey().name());

            for (Module module : moduleCategoryListEntry.getValue()) {
                tab.addSubTab(new SubTab<>(module.getName(), subTab -> subTab.getObject().setToggled(!subTab.getObject().isToggled()), module));
            }

            tabGui.addTab(tab);
        }
    }

    public static TabGui<Module> tabGui = new TabGui<>();
    static FontRenderer fontRenderer = Minecraft.getMinecraft().fontRenderer;
    private Minecraft mc = getMinecraft();


    public static class ModuleComparator implements Comparator<Module> {

        @Override
        public int compare(Module arg0, Module arg1) {
            if (Minecraft.getMinecraft().fontRenderer.getStringWidth(arg0.getName()) > getMinecraft().fontRenderer.getStringWidth(arg1.getName())) {
                return -1;
            }
            if (Minecraft.getMinecraft().fontRenderer.getStringWidth(arg0.getName()) > getMinecraft().fontRenderer.getStringWidth(arg1.getName())) {
                return 1;
            }
            return 0;
        }
    }

    private final ResourceLocation watermark = new ResourceLocation(Refrence.MOD_ID, "textures/watermark.png");


    @SubscribeEvent
    public void renderOverlay(RenderGameOverlayEvent event) {

        // blah blah render name
        Collections.sort(ArcaneX.moduleManager.modules, new ModuleComparator());
        ScaledResolution sr = new ScaledResolution(mc);
        FontRenderer fr = mc.fontRenderer;
        if (event.getType() == RenderGameOverlayEvent.ElementType.TEXT) {
            fr.drawStringWithShadow("ArcaneX", 2, 1, 0xffffffff);
            fr.drawStringWithShadow(Refrence.VERSION, 54, 1, 0xfffffabc);
        }

        //clientlogo
        if (event.getType() == RenderGameOverlayEvent.ElementType.HELMET) {
            mc.renderEngine.bindTexture(watermark);
            drawScaledCustomSizeModalRect(-2, sr.getScaledHeight() - 51, 0, 0, 50, 50, 50, 50, 50, 50);
        }
        //arraylist
        if (event.getType() == RenderGameOverlayEvent.ElementType.TEXT) {
            int y = 2;
            final int[] counter = {1};
            for (Module mod : ArcaneX.moduleManager.getModuleList()) {
                if (!mod.getName().equalsIgnoreCase("") && mod.isToggled()) {
                    fr.drawStringWithShadow(mod.getName(), sr.getScaledWidth() - fr.getStringWidth(mod.getName()) - 2, y, rainbow(counter[0] * 300));
                    y += fr.FONT_HEIGHT;
                    counter[0]++;
                }
            }
        }
        //TabGui

        tabGui.render(5, (2 + fontRenderer.FONT_HEIGHT) * 3);

    }

    public static int rainbow(int delay) {
        double rainbowState = Math.ceil((System.currentTimeMillis() + delay) / 20.0);
        rainbowState %= 360;
        return Color.getHSBColor((float) (rainbowState / 360.0f), 0.5f, 1f).getRGB();
    }

    @SubscribeEvent
    public void onKey(InputEvent.KeyInputEvent event) {
        if (Keyboard.isCreated()) {
            if (Keyboard.getEventKeyState()) {
                int keyCode = Keyboard.getEventKey();
                tabGui.handleKey(keyCode);
            }
        }
    }
}
