package me.arcanedev.arcanex.module.modules.player;

import me.arcanedev.arcanex.events.network.PacketEvent;
import me.arcanedev.arcanex.module.Category;
import me.arcanedev.arcanex.module.Module;
import me.bush.eventbus.annotation.EventListener;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayer;
import org.lwjgl.input.Keyboard;

public class NoSlow extends Module {
    public NoSlow() {
        super("NoSlow", "go zooom", Category.PLAYER);
    }

    @EventListener
    public void onUpdate(PacketEvent.Send event) {
        if (event.getPacket() instanceof CPacketPlayer){
            mc.player.connection.sendPacket(new CPacketHeldItemChange(mc.player.inventory.currentItem));
        }
    }
}
