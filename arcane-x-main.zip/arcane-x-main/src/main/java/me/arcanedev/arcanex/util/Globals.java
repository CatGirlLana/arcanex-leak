package me.arcanedev.arcanex.util;

import net.minecraft.client.Minecraft;
import me.arcanedev.arcanex.ArcaneX;

public interface Globals {
    Minecraft mc = Minecraft.getMinecraft();

    default boolean fullNullCheck() {
        return mc.player != null && mc.world != null;
    }
}