package me.arcanedev.arcanex.mixin.mixins;


import me.arcanedev.arcanex.ArcaneX;
import me.arcanedev.arcanex.events.TickEvent;
import me.arcanedev.arcanex.module.Module;
import net.minecraft.client.entity.EntityPlayerSP;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(EntityPlayerSP.class)
public abstract class MixinEntityPlayerSP {

    @Inject(method = "onUpdate", at = @At("HEAD"))
    public void preUpdate(CallbackInfo ci) {
        TickEvent.Pre event = new TickEvent.Pre();
        ArcaneX.EVENT_BUS.post(event);
    }

    @Inject(method = "onUpdate", at = @At("TAIL"))
    public void postUpdate(CallbackInfo ci) {
        TickEvent.Post event = new TickEvent.Post();
        ArcaneX.EVENT_BUS.post(event);
    }


}

