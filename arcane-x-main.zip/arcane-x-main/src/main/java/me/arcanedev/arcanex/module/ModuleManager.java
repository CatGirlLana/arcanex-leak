package me.arcanedev.arcanex.module;

import me.arcanedev.arcanex.ArcaneX;
import me.arcanedev.arcanex.events.Render2DEvent;
import me.arcanedev.arcanex.module.modules.player.NoSlow;
import me.arcanedev.arcanex.module.modules.player.Sprint;
import me.arcanedev.arcanex.module.modules.render.FullBright;
import me.bush.eventbus.annotation.EventListener;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {

    public static List<Module> modules = new ArrayList<>();
    public ModuleManager() {
        //player
        modules.add(new Sprint());
        modules.add(new NoSlow());
        //render
        modules.add(new FullBright());
        //exploits

        //pvp

        //client
    }



    public Module getModules (String name) {
        for(Module m : this.modules) {
            if(m.getName().equalsIgnoreCase(name)) {
                return m;
            }
        }
        return null;
    }

    public static List<Module> getModuleList() {
        return modules;
    }

    public static List<Module> getModuleByCategory(Category c) {
        List<Module> modules = new ArrayList<Module>();
        for (Module m : ArcaneX.moduleManager.modules) {
            if (m.getCategory() == c)
                modules.add(m);
        }
        return modules;
    }

    @SubscribeEvent
    public void onRender2D(RenderGameOverlayEvent event){
        ArcaneX.EVENT_BUS.post(new Render2DEvent());
    }
}
