package me.arcanedev.arcanex.util.render;

import me.arcanedev.arcanex.util.Globals;

public class ScaleUtil implements Globals {
    public static float centerTextY(float y, float height) {
        return (y + (height / 2.0f)) - (mc.fontRenderer.FONT_HEIGHT / 2.0f);
    }
}