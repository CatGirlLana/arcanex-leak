package me.arcanedev.arcanex.util.render;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.arcanedev.arcanex.ui.Hud;

import java.awt.*;

public class ColorUtil {

    public static Color releasedDynamicRainbow(int delay, float saturation, float brightness) {
        double rainbowState = Math.ceil((double) (System.currentTimeMillis() + (long) delay) / 20.0);
        return Color.getHSBColor((float) (rainbowState % 360.0 / 360.0), saturation / 255.0f, brightness / 255.0f);
    }

    int r;
    int g;
    int b;
    int a;

    public ColorUtil(int r, int g, int b) {
        this.r = r;
        this.g = g;
        this.b = b;
        this.a = 255;
    }


    public static int toHex(int r, int g, int b) {
        return 0xFF000000 | (r & 0xFF) << 16 | (g & 0xFF) << 8 | b & 0xFF;
    }

    public static float [] toRGBA(int hex) {
        // r, g, b, a
        return new float[]{(hex >> 16 & 0xff) / 255.0f, (hex >> 8 & 0xff) / 255.0f, (hex & 0xff) / 255.0f, (hex >> 24 & 0xff) / 255.0f};
    }

    public static ChatFormatting nameColorFromSetting;

    public static ChatFormatting getNameColorFromSetting(Hud.NameColor setting) {
        if (setting.equals(Hud.NameColor.DarkRed)) {
            nameColorFromSetting = ChatFormatting.DARK_RED;
        }
        if (setting.equals(Hud.NameColor.Red)) {
            nameColorFromSetting = ChatFormatting.RED;
        }
        if (setting.equals(Hud.NameColor.Gold)) {
            nameColorFromSetting = ChatFormatting.GOLD;
        }
        if (setting.equals(Hud.NameColor.Yellow)) {
            nameColorFromSetting = ChatFormatting.YELLOW;
        }
        if (setting.equals(Hud.NameColor.DarkGreen)) {
            nameColorFromSetting = ChatFormatting.DARK_GREEN;
        }
        if (setting.equals(Hud.NameColor.Green)) {
            nameColorFromSetting = ChatFormatting.GREEN;
        }
        if (setting.equals(Hud.NameColor.Aqua)) {
            nameColorFromSetting = ChatFormatting.AQUA;
        }
        if (setting.equals(Hud.NameColor.DarkAqua)) {
            nameColorFromSetting = ChatFormatting.DARK_AQUA;
        }
        if (setting.equals(Hud.NameColor.DarkBlue)) {
            nameColorFromSetting = ChatFormatting.DARK_BLUE;
        }
        if (setting.equals(Hud.NameColor.Blue)) {
            nameColorFromSetting = ChatFormatting.BLUE;
        }
        if (setting.equals(Hud.NameColor.LightPurple)) {
            nameColorFromSetting = ChatFormatting.LIGHT_PURPLE;
        }
        if (setting.equals(Hud.NameColor.DarkPurple)) {
            nameColorFromSetting = ChatFormatting.DARK_PURPLE;
        }
        if (setting.equals(Hud.NameColor.White)) {
            nameColorFromSetting = ChatFormatting.WHITE;
        }
        if (setting.equals(Hud.NameColor.Gray)) {
            nameColorFromSetting = ChatFormatting.GRAY;
        }
        if (setting.equals(Hud.NameColor.DarkGray)) {
            nameColorFromSetting = ChatFormatting.DARK_GRAY;
        }
        if (setting.equals(Hud.NameColor.Black)) {
            nameColorFromSetting = ChatFormatting.BLACK;
        }
        return nameColorFromSetting;
    }

    public static ChatFormatting nameBracketFromSetting;

    public static ChatFormatting getBracketColorFromSetting(Hud.BracketColor setting) {
        if (setting.equals(Hud.BracketColor.DarkRed)) {
            nameBracketFromSetting = ChatFormatting.DARK_RED;
        }
        if (setting.equals(Hud.BracketColor.Red)) {
            nameBracketFromSetting = ChatFormatting.RED;
        }
        if (setting.equals(Hud.BracketColor.Gold)) {
            nameBracketFromSetting = ChatFormatting.GOLD;
        }
        if (setting.equals(Hud.BracketColor.Yellow)) {
            nameBracketFromSetting = ChatFormatting.YELLOW;
        }
        if (setting.equals(Hud.BracketColor.DarkGreen)) {
            nameBracketFromSetting = ChatFormatting.DARK_GREEN;
        }
        if (setting.equals(Hud.BracketColor.Green)) {
            nameBracketFromSetting = ChatFormatting.GREEN;
        }
        if (setting.equals(Hud.BracketColor.Aqua)) {
            nameBracketFromSetting = ChatFormatting.AQUA;
        }
        if (setting.equals(Hud.BracketColor.DarkAqua)) {
            nameBracketFromSetting = ChatFormatting.DARK_AQUA;
        }
        if (setting.equals(Hud.BracketColor.DarkBlue)) {

        }
        if (setting.equals(Hud.BracketColor.Blue)) {
            nameBracketFromSetting = ChatFormatting.BLUE;
        }
        if (setting.equals(Hud.BracketColor.LightPurple)) {
            nameBracketFromSetting = ChatFormatting.LIGHT_PURPLE;
        }
        if (setting.equals(Hud.BracketColor.DarkPurple)) {
            nameBracketFromSetting = ChatFormatting.DARK_PURPLE;
        }
        if (setting.equals(Hud.BracketColor.White)) {
            nameBracketFromSetting = ChatFormatting.WHITE;
        }
        if (setting.equals(Hud.BracketColor.Gray)) {
            nameBracketFromSetting = ChatFormatting.GRAY;
        }
        if (setting.equals(Hud.BracketColor.DarkGray)) {
            nameBracketFromSetting = ChatFormatting.DARK_GRAY;
        }
        if (setting.equals(Hud.BracketColor.Black)) {
            nameBracketFromSetting = ChatFormatting.BLACK;
        }
        return nameBracketFromSetting;
    }
}