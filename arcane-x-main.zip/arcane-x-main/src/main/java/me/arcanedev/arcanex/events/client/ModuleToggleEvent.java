package me.arcanedev.arcanex.events.client;

import net.minecraftforge.fml.common.eventhandler.Event;
import me.arcanedev.arcanex.module.Module;

public class ModuleToggleEvent extends Event {
    private final Module module;

    public ModuleToggleEvent(Module module) {
        this.module = module;
    }

    public Module getModule() {
        return module;
    }
}