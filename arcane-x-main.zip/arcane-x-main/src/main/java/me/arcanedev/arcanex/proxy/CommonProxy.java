package me.arcanedev.arcanex.proxy;

public class CommonProxy {
}
