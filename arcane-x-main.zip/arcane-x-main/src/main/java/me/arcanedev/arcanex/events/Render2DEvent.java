package me.arcanedev.arcanex.events;

import me.bush.eventbus.event.Event;

public class Render2DEvent extends Event {
    @Override
    protected boolean isCancellable() {
        return false;
    }
}
