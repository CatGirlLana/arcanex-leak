package me.arcanedev.arcanex.module.modules.render;

import net.minecraft.init.MobEffects;
import net.minecraft.potion.PotionEffect;
import me.arcanedev.arcanex.module.Category;
import me.arcanedev.arcanex.module.Module;
import me.arcanedev.arcanex.setting.Setting;
import me.arcanedev.arcanex.util.Globals;

public class FullBright extends Module {
    public FullBright() {
        super("Fullbright", "Makes your game brighter", Category.RENDER);
    }

    public static final Setting<Enum> mode = new Setting<>("Mode", lightMode.Gamma);
    public static float oldGamma = -1.0f;

    public String getDisplayInfo() {
        return mode.getValue().name();
    }

    @Override
    public void onDisable() {
        if (oldGamma != -1.0f) {
            Globals.mc.gameSettings.gammaSetting = oldGamma;
            oldGamma = -1.0f;
        }

        if (Globals.mc.player.isPotionActive(MobEffects.NIGHT_VISION)) {
            Globals.mc.player.removePotionEffect(MobEffects.NIGHT_VISION);
        }
    }

    @Override
    public void onUpdate() {
        if (mode.getValue() == lightMode.Gamma) {
            if (oldGamma == -1.0f) {
                oldGamma = Globals.mc.gameSettings.gammaSetting;
            }

            if (Globals.mc.player.isPotionActive(MobEffects.NIGHT_VISION)) {
                Globals.mc.player.removePotionEffect(MobEffects.NIGHT_VISION);
            }

            Globals.mc.gameSettings.gammaSetting = 100.0f;
        } else if (mode.getValue() == lightMode.Potion) {
            if (oldGamma != -1.0f) {
                Globals.mc.gameSettings.gammaSetting = oldGamma;
                oldGamma = -1.0f;
            }

            if (!Globals.mc.player.isPotionActive(MobEffects.NIGHT_VISION)) {
                Globals.mc.player.addPotionEffect(new PotionEffect(MobEffects.NIGHT_VISION, (int) Long.MAX_VALUE));
            }
        }
    }

    public enum lightMode {
        Gamma,
        Potion;
    }
}