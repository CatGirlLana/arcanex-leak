package me.arcanedev.arcanex.module.modules.player;

import me.arcanedev.arcanex.module.Category;
import me.arcanedev.arcanex.module.Module;
import me.bush.eventbus.annotation.EventListener;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

import javax.swing.text.JTextComponent;

import static me.arcanedev.arcanex.ArcaneX.mc;


import net.minecraft.client.settings.KeyBinding;
import me.arcanedev.arcanex.setting.Setting;
import me.arcanedev.arcanex.util.Globals;

public class Sprint extends Module {
    public Sprint() {
        super("Sprint", "Automatically sprints for you", Category.PLAYER);
    }

    public static final Setting<Mode> mode = new Setting<>("Mode", Mode.Legit);

    public String getDisplayInfo() {
        return mode.getValue().name();
    }

    @Override
    public void onUpdate() {
        if (!Globals.mc.player.isSprinting()) {
            switch (mode.getValue()) {
                case Rage:
                case Always: {
                    Globals.mc.player.setSprinting(Globals.mc.gameSettings.keyBindForward.isKeyDown() || mode.getValue() == Mode.Always);
                    break;
                }

                case Legit: {
                    if (Globals.mc.player.isSneaking() || Globals.mc.player.getFoodStats().getFoodLevel() <= 6 || Globals.mc.player.collidedHorizontally || Globals.mc.player.isHandActive()) {
                        break;
                    }

                    KeyBinding.setKeyBindState(Globals.mc.gameSettings.keyBindSprint.getKeyCode(), true);
                    break;
                }
            }
        }
    }

    public enum Mode {
        /**
         * If to always sprint
         */
        Rage,

        /**
         * If to sprint in all directions, yet non-strict
         */
        Always,

        /**
         * More checks to check if you are able to sprint. Eg hunger above 6, not colliding with a wall, not eating, etc
         */
        Legit
    }
}