package me.arcanedev.arcanex.util.client;

import com.google.gson.JsonElement;

public class ClientEnumConverter {
    private final Class<? extends Enum> clazz;

    public ClientEnumConverter(Class<? extends Enum> clazz) {
        this.clazz = clazz;
    }


    public Enum doBackward(JsonElement jsonElement) {
        try {
            return Enum.valueOf(this.clazz, jsonElement.getAsString());
        } catch (IllegalArgumentException e) {
            return null;
        }
    }
}