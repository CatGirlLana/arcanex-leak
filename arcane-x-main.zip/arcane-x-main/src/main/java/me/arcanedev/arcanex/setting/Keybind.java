package me.arcanedev.arcanex.setting;

public class Keybind extends Setting<Integer> {
    public Keybind(String name, Integer value) {
        super(name, value);
    }
}