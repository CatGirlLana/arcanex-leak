package me.arcanedev.arcanex.proxy;

public class ClientProxy extends CommonProxy {

}
