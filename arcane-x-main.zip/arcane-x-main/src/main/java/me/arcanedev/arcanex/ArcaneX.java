package me.arcanedev.arcanex;

import me.arcanedev.arcanex.events.Render2DEvent;
import me.arcanedev.arcanex.module.Category;
import me.arcanedev.arcanex.module.Module;
import me.arcanedev.arcanex.module.ModuleManager;
import me.arcanedev.arcanex.ui.Hud;
import me.arcanedev.arcanex.ui.tab.SubTab;
import me.arcanedev.arcanex.ui.tab.Tab;
import me.arcanedev.arcanex.ArcaneX;
import me.arcanedev.arcanex.util.Refrence;
import me.bush.eventbus.annotation.EventListener;
import me.bush.eventbus.bus.EventBus;
import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import org.lwjgl.input.Keyboard;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

@Mod(modid = Refrence.MOD_ID, name = Refrence.NAME, version = Refrence.VERSION)
public class ArcaneX {

    public static EventBus EVENT_BUS;
    public static ModuleManager moduleManager;
    public static Hud hud;
    public static String mainFolder;

    @Mod.Instance
    public ArcaneX instance;
    public static ArcaneX INSTANCE;


    public static Minecraft mc = Minecraft.getMinecraft();

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        EVENT_BUS = new EventBus();
        moduleManager = new ModuleManager();
        hud = new Hud();
        hud.initTabGui();
        EVENT_BUS.subscribe(moduleManager);
        EVENT_BUS.subscribe(instance);
        EVENT_BUS.subscribe(hud);
        MinecraftForge.EVENT_BUS.register(hud);

    }

    @Mod.EventHandler
    public void PostInit (FMLPreInitializationEvent event) {
    }


}
