package me.arcanedev.arcanex.module.modules.render;

import org.lwjgl.input.Keyboard;

import me.arcanedev.arcanex.module.Category;
import me.arcanedev.arcanex.module.Module;

public class Tracers extends Module{
	
    public Tracers(){
        super("Tracers", "Epic lines", Category.RENDER);
    }


}
