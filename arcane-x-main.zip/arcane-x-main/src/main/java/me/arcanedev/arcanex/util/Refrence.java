package me.arcanedev.arcanex.util;

public class Refrence {

    public static final String MOD_ID = "arx";
    public static final String NAME = "ArcaneX";
    public static final String VERSION = "0.0.1";
    public static final String ACCEPTED_VERSIONS = "[1.12.2]";
    public static final String CLIENT_PROXY_CLASS = "me.arcanedev.arcxanex.proxy.ClientProxy";
    public static final String COMMON_PROXY_CLASS = "me.arcanedev.arcanex.proxy.CommonProxy";
}
