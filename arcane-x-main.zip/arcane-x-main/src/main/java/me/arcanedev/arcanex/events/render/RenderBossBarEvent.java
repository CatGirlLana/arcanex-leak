package me.arcanedev.arcanex.events.render;


import net.minecraftforge.fml.common.eventhandler.Cancelable;
import net.minecraftforge.fml.common.eventhandler.Event;

@Cancelable
public class RenderBossBarEvent extends Event {

}