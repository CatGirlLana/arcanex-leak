package me.arcanedev.arcanex.mixin.mixins;

 import me.arcanedev.arcanex.ArcaneX;
 import me.arcanedev.arcanex.events.Render2DEvent;
 import net.minecraft.client.gui.GuiIngame;
 import org.spongepowered.asm.mixin.Mixin;
 import org.spongepowered.asm.mixin.injection.At;
 import org.spongepowered.asm.mixin.injection.Inject;
 import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

 @Mixin(GuiIngame.class)
 public class MixinGuiIngame {
     @Inject(method = "renderGameOverlay", at = @At("RETURN"))
     private void renderTooltip(float p_renderGameOverlay_1_, CallbackInfo ci) {
         ArcaneX.EVENT_BUS.post(new Render2DEvent());
     }
 }
